@extends('../../include/layout/master')

@section('title','- Marine Insurance')

@section('content')


        <section id="about">
            <div class="about">
            <h1 class="m-4"> Marine Insurance </h1>
                <div class="container-fluid">
                    <div class="row mb-4">
                        <div class="col-md-7">
                            <img src="img/marine.jpg" style="width: 800px;">
                        </div>
                        <div class="col-md-4">
                            <div class="container">
                                <form action="{{ url('/') }}/marine-insurance-plan" method="post"  class="form" style="border: 1px solid lightgray; padding: 20px;">
                                @csrf
                                    <div class="form-group">
                                        <label><b>Your Name</b></label>
                                        <input type="text" name="name" class="form-control mb-4" required>
                                        <label><b>Phone Number</b></label>
                                        <input type="text" name="phone" class="form-control mb-4" required>
                                        <input type="submit" class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-1">
                        <div>
                    </div>    
                </div>
            </div>
        </section>

@stop