@extends('../../include/layout/master')

@section('title','- about')

@section('content')


        <section id="about">
            <div class="about">
            <h1 class="m-4"> Car Insurance Plans </h1>
                <div class="container-fluid">
                    <div class="row">
                    

                    @if(isset($rs))
					  @foreach ($rs as $rse)


                      @if(isset($rs1))
                      @foreach ($rs1 as $rse1)

                        @if(isset($rs2))
                        @foreach ($rs2 as $rse2)

                        <div class="plan mb-4">
                            <div class="row">
                                <div class="col-md-2">
                                </div>
                                <div class="col-md-8" style="border: 1px solid lightgray; border-radius: 5px;">
                                    <div class="row">
                                        <div class="col-md-3 p-4" style="border-right: 1px solid lightgray; text-align: center;">
                                            <img src="img/logo/{{ $rse->logo }}" style="width: 100px; height: 80px;">
                                            <div class="mt-2 text-dark fw-bold"> {{ $rse->title }}</div>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="row">
                                                <div class="col-md-2 p-4">
                                                    <div>Rate</div>
                                                    <div class="text-dark fw-bold">{{ $rse->rate }} %</div>
                                                </div>
                                                <div class="col-md-4 p-4">
                                                    <div>Installment Plan</div>
                                                    <span class="text-dark fw-bold">Rs </span><span class="text-dark fw-bold">{{ number_format($rse1->value*$rse->rate/100/6,2,'.',',') }}</span><span class="text-dark fw-bold">/month</span>
                                                </div>
                                                <div class="col-md-3 p-4">
                                                    <div>Total</div>
                                                    <div class="text-dark fw-bold">Rs {{ number_format($rse1->value*$rse->rate/100,2,'.',',') }}</div>
                                                </div>
                                                <div class="col-md-3 p-4">
                                                    <!-- <button type="submit" class="form-control mb-2">Enquire</button> -->
                                                    
                                                    <form action="{{ url('/') }}/car-insurance-plan-premium" method="post" class="mb-2">
                                                        @csrf
                                                        <input name="brand" type="text" value="{{ $rse2->brand }}" hidden>
                                                        <input name="model" type="text" value="{{ $rse2->model }}" hidden>
                                                        <input name="year" type="text" value="{{ $rse2->year }}" hidden>
                                                        <input name="value" type="text" value="{{ $rse2->value }}" hidden>
                                                        <input name="name" type="text" value="{{ $rse2->name }}" hidden>
                                                        <input name="phone" type="text" value="{{ $rse2->phone }}" hidden>
                                                        <input name="logo" type="text" value="img/logo/{{ $rse->logo }}" hidden>
                                                        <input name="title" type="text" value="{{ $rse->title }}" hidden>
                                                        <input name="rate" type="text" value="{{ $rse->rate }}" hidden>
                                                        <input name="installment" type="text" value="{{ $rse1->value*$rse->rate/100/6 }}" hidden>
                                                        <input name="total" type="text" value="{{ $rse1->value*$rse->rate/100 }}" hidden>
                                                        <button name="submit" type="submit" class="form-control">Enquire</button>
                                                    </form>
                                                    <form action="{{ url('/') }}/car-insurance-plan-buy" method="get" class="mb-2">
                                                        @csrf
                                                        <input name="brand" type="text" value="{{ $rse2->brand }}" hidden>
                                                        <input name="model" type="text" value="{{ $rse2->model }}" hidden>
                                                        <input name="year" type="text" value="{{ $rse2->year }}" hidden>
                                                        <input name="value" type="text" value="{{ $rse2->value }}" hidden>
                                                        <input name="name" type="text" value="{{ $rse2->name }}" hidden>
                                                        <input name="phone" type="text" value="{{ $rse2->phone }}" hidden>
                                                        <input name="logo" type="text" value="img/logo/{{ $rse->logo }}" hidden>
                                                        <input name="title" type="text" value="{{ $rse->title }}" hidden>
                                                        <input name="rate" type="text" value="{{ $rse->rate }}" hidden>
                                                        <input name="installment" type="text" value="{{ $rse1->value*$rse->rate/100/6 }}" hidden>
                                                        <input name="total" type="text" value="{{ $rse1->value*$rse->rate/100 }}" hidden>
                                                        <button name="submit" type="submit" class="form-control">Buy</button>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="row">    
                                                <div class="col-md-3 p-4">+ More Details</div>
                                                <div class="col-md-3 p-4"><input type="checkbox" id="tracker" name="tracker" value="">
                                                <label for="vehicle1"> Add Tracker</label><br></div>
                                                <div class="col-md-3 p-4"></div>
                                                <div class="col-md-3 p-4"></div>    
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                </div>
                            </div>
                        </div>

                        @endforeach 
                        @endif

                        @endforeach 
                        @endif

                        @endforeach 
                        @endif

                    </div>  
                </div>
            </div>
        </section>


@stop