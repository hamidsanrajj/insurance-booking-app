@extends('../../include/layout/master')

@section('title','- about')

@section('content')


        <section id="about">
            <div class="about">
                <div class="container-fluid">
                    <div class="row mb-4 p-4 m-4">
                        
                        <h1 class="text-center text-primary">Your request has been submitted</h1>
                        <h3 class="text-center">Please wait for our response</h3>
                                
                    </div>    
                </div>
            </div>
        </section>

@stop