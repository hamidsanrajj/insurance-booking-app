@extends('../../include/layout/master')

@section('title','- Enquire')

@section('content')


        <section id="about">
            <div class="about">
                <div class="container-fluid">
                    <div class="row mb-4 p-4 m-4">
                        
                        <h1 class="text-center text-primary">Your request has been submitted</h1>
                        <h3 class="text-center">Please wait for our response</h3>
                        
                        @if(isset($rs))
                        @foreach ($rs as $rse)

                            <h1 class="text-center">{{$rse->order_number }}</h1>
                            <h3 class="text-center">Your Order Number</h3>
                            
                        @endforeach
                        @endif

                    </div>    
                </div>
            </div>
        </section>

@stop