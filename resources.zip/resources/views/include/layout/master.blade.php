@include('../../include/head')
@include('../../include/header')


@yield('content')


@include('../../include/footer')