

<?php $__env->startSection('title','- about'); ?>

<?php $__env->startSection('content'); ?>


        <section id="about">
            <div class="about">
            <h1 class="m-4"> Car Insurance Plans </h1>
                <div class="container-fluid">
                    <div class="row">
                    

                    <?php if(isset($rs)): ?>
					  <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                      <?php if(isset($rs1)): ?>
                      <?php $__currentLoopData = $rs1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(isset($rs2)): ?>
                        <?php $__currentLoopData = $rs2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="plan mb-4">
                            <div class="row">
                                <div class="col-md-2">
                                </div>
                                <div class="col-md-8" style="border: 1px solid lightgray; border-radius: 5px;">
                                    <div class="row">
                                        <div class="col-md-3 p-4" style="border-right: 1px solid lightgray; text-align: center;">
                                            <img src="img/logo/<?php echo e($rse->logo); ?>" style="width: 100px; height: 80px;">
                                            <div class="mt-2 text-dark fw-bold"> <?php echo e($rse->title); ?></div>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="row">
                                                <div class="col-md-2 p-4">
                                                    <div>Rate</div>
                                                    <div class="text-dark fw-bold"><?php echo e($rse->rate); ?> %</div>
                                                </div>
                                                <div class="col-md-4 p-4">
                                                    <div>Installment Plan</div>
                                                    <span class="text-dark fw-bold">Rs </span><span class="text-dark fw-bold"><?php echo e(number_format($rse1->value*$rse->rate/100/6,2,'.',',')); ?></span><span class="text-dark fw-bold">/month</span>
                                                </div>
                                                <div class="col-md-3 p-4">
                                                    <div>Total</div>
                                                    <div class="text-dark fw-bold">Rs <?php echo e(number_format($rse1->value*$rse->rate/100,2,'.',',')); ?></div>
                                                </div>
                                                <div class="col-md-3 p-4">
                                                    <!-- <button type="submit" class="form-control mb-2">Enquire</button> -->
                                                    
                                                    <form action="<?php echo e(url('/')); ?>/car-insurance-plan-premium" method="post" class="mb-2">
                                                        <?php echo csrf_field(); ?>
                                                        <input name="brand" type="text" value="<?php echo e($rse2->brand); ?>" hidden>
                                                        <input name="model" type="text" value="<?php echo e($rse2->model); ?>" hidden>
                                                        <input name="year" type="text" value="<?php echo e($rse2->year); ?>" hidden>
                                                        <input name="value" type="text" value="<?php echo e($rse2->value); ?>" hidden>
                                                        <input name="name" type="text" value="<?php echo e($rse2->name); ?>" hidden>
                                                        <input name="phone" type="text" value="<?php echo e($rse2->phone); ?>" hidden>
                                                        <input name="logo" type="text" value="img/logo/<?php echo e($rse->logo); ?>" hidden>
                                                        <input name="title" type="text" value="<?php echo e($rse->title); ?>" hidden>
                                                        <input name="rate" type="text" value="<?php echo e($rse->rate); ?>" hidden>
                                                        <input name="installment" type="text" value="<?php echo e($rse1->value*$rse->rate/100/6); ?>" hidden>
                                                        <input name="total" type="text" value="<?php echo e($rse1->value*$rse->rate/100); ?>" hidden>
                                                        <button name="submit" type="submit" class="form-control">Enquire</button>
                                                    </form>
                                                    <form action="<?php echo e(url('/')); ?>/car-insurance-plan-buy" method="get" class="mb-2">
                                                        <?php echo csrf_field(); ?>
                                                        <input name="brand" type="text" value="<?php echo e($rse2->brand); ?>" hidden>
                                                        <input name="model" type="text" value="<?php echo e($rse2->model); ?>" hidden>
                                                        <input name="year" type="text" value="<?php echo e($rse2->year); ?>" hidden>
                                                        <input name="value" type="text" value="<?php echo e($rse2->value); ?>" hidden>
                                                        <input name="name" type="text" value="<?php echo e($rse2->name); ?>" hidden>
                                                        <input name="phone" type="text" value="<?php echo e($rse2->phone); ?>" hidden>
                                                        <input name="logo" type="text" value="img/logo/<?php echo e($rse->logo); ?>" hidden>
                                                        <input name="title" type="text" value="<?php echo e($rse->title); ?>" hidden>
                                                        <input name="rate" type="text" value="<?php echo e($rse->rate); ?>" hidden>
                                                        <input name="installment" type="text" value="<?php echo e($rse1->value*$rse->rate/100/6); ?>" hidden>
                                                        <input name="total" type="text" value="<?php echo e($rse1->value*$rse->rate/100); ?>" hidden>
                                                        <button name="submit" type="submit" class="form-control">Buy</button>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="row">    
                                                <div class="col-md-3 p-4">+ More Details</div>
                                                <div class="col-md-3 p-4"><input type="checkbox" id="tracker" name="tracker" value="">
                                                <label for="vehicle1"> Add Tracker</label><br></div>
                                                <div class="col-md-3 p-4"></div>
                                                <div class="col-md-3 p-4"></div>    
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endif; ?>

                    </div>  
                </div>
            </div>
        </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance-aggregator\resources\views/include/views/insurance/plan/car.blade.php ENDPATH**/ ?>