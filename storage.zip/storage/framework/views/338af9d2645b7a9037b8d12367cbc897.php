

<?php $__env->startSection('title','- about'); ?>

<?php $__env->startSection('content'); ?>


        <section id="about">
            <div class="about">
                <div class="container-fluid-less">
                
                    <div class="row p-4">
                        <div class="col-md-4">
                        <h1>Add Car Plan </h1>
                            <form action="<?php echo e(url('/')); ?>/add-car-insurance-plan" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-4">
                                    <label><b>Upload Company Logo</b></label>
                                    <input type="text" name="logo" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Title</b></label>
                                    <input type="text" name="title" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Rate</b></label>
                                    <input type="text" name="rate" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit" class="form-control">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                        <h1>Add Health Plan </h1>
                            <form action="<?php echo e(url('/')); ?>/car-insurance-plan" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-4">
                                    <label><b>Upload Company Logo</b></label>
                                    <input type="text" name="logo" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Title</b></label>
                                    <input type="text" name="title" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Rate</b></label>
                                    <input type="text" name="rate" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit" class="form-control">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                        <h1>Add Travel Plan </h1>
                            <form action="<?php echo e(url('/')); ?>/car-insurance-plan" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-4">
                                    <label><b>Upload Company Logo</b></label>
                                    <input type="text" name="logo" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Title</b></label>
                                    <input type="text" name="title" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Rate</b></label>
                                    <input type="text" name="rate" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit" class="form-control">
                                </div>
                            </form>
                        </div>
                        <div class="col-md-4">
                        <h1>Add Marine Plan </h1>
                            <form action="<?php echo e(url('/')); ?>/car-insurance-plan" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-4">
                                    <label><b>Upload Company Logo</b></label>
                                    <input type="text" name="logo" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Title</b></label>
                                    <input type="text" name="title" class="form-control">
                                </div>
                                <div class="form-group mb-4">
                                    <label><b>Plan Rate</b></label>
                                    <input type="text" name="rate" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit" class="form-control">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance-aggregator\resources\views/include/views/insurance/plan/addPlan.blade.php ENDPATH**/ ?>