

<?php $__env->startSection('title','- Marine Insurance'); ?>

<?php $__env->startSection('content'); ?>


        <section id="about">
            <div class="about">
            <h1 class="m-4"> Marine Insurance </h1>
                <div class="container-fluid">
                    <div class="row mb-4">
                        <div class="col-md-7">
                            <img src="img/marine.jpg" style="width: 800px;">
                        </div>
                        <div class="col-md-4">
                            <div class="container">
                                <form action="<?php echo e(url('/')); ?>/marine-insurance-plan" method="post"  class="form" style="border: 1px solid lightgray; padding: 20px;">
                                <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label><b>Your Name</b></label>
                                        <input type="text" name="name" class="form-control mb-4" required>
                                        <label><b>Phone Number</b></label>
                                        <input type="text" name="phone" class="form-control mb-4" required>
                                        <input type="submit" class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-1">
                        <div>
                    </div>    
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance-aggregator\resources\views/include/views/insurance/marine.blade.php ENDPATH**/ ?>