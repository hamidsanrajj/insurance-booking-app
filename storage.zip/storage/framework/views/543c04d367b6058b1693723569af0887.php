

<?php $__env->startSection('title','- about'); ?>

<?php $__env->startSection('content'); ?>


        <section id="about">
            <div class="about">
                <div class="container-fluid-less">
                    <div class="row mb-4 p-4 m-4">
                        
                        <h1 class="text-center text-primary">Your request has been submitted</h1>
                        <h3 class="text-center">Please wait for our response</h3>
                                
                    </div>    
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance-aggregator\resources\views/include/views/insurance/carInsurance.blade.php ENDPATH**/ ?>