

<?php $__env->startSection('title','- Health Insurance'); ?>

<?php $__env->startSection('content'); ?>


        <section id="about">
            <div class="about">
            <h1 class="m-4"> Health Insurance </h1>
                <div class="container-fluid">
                    <div class="row mb-4">
                        <div class="col-md-7">
                            <img src="img/health.jpg" style="width: 800px;">
                        </div>
                        <div class="col-md-4">
                            <div class="container">
                                <form action="<?php echo e(url('/')); ?>/health-insurance-plan" method="post"  class="form" style="border: 1px solid lightgray; padding: 20px;">
                                <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label>Person</label>
                                        <select name="person" class="form-control mb-4" required>
                                            <option disabled value="" selected>Select</option>
                                            <option value="Myself">Myself</option>
                                            <option value="Family">Family</option>
                                            <option value="Parents">Parents</option>
                                        </select>
                                        <label>Age</label>
                                        <input name="age" type="text" class="form-control mb-4" required>
                                        <label>Hospitalization Cover</label>
                                        <select name="cover" class="form-control mb-4" required>
                                            <option disabled value="" selected>Select</option>
                                            <option value="60k-2lac">60k-2lac</option>
                                            <option value="2lac-5lac">2lac-5lac</option>
                                            <option value="5lac above">5lac above</option>
                                        </select>
                                        <label>Your Name</label>
                                        <input name="name" type="text" class="form-control mb-4" required>
                                        <label>Phone</label>
                                        <input name="phone" type="text" class="form-control mb-4" required>
                                        <input type="submit" class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-1">
                        <div>
                    </div>    
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance-aggregator\resources\views/include/views/insurance/health.blade.php ENDPATH**/ ?>