

<?php $__env->startSection('title','- Buy Insurance'); ?>

<?php $__env->startSection('content'); ?>


        <section id="about">
            <div class="about">
                <div class="container-fluid">
                    <div class="row mb-4 p-4 m-4">
                        
                        <h1 class="text-center text-primary">Your request has been submitted</h1>
                        <h3 class="text-center">Please wait for our response</h3>
                        
                        <?php if(isset($rs)): ?>
                        <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <h1 class="text-center"><?php echo e($rse->order_number); ?></h1>
                            <h3 class="text-center">Your Order Number</h3>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                    </div>    
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance-aggregator\resources\views/include/views/insurance/message/buy.blade.php ENDPATH**/ ?>