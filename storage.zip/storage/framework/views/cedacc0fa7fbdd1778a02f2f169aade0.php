

<?php $__env->startSection('title','- Car Insurance'); ?>

<?php $__env->startSection('content'); ?>


        <section id="about">
            <div class="about">
            <h1 class="m-4"> Car Insurance </h1>
                <div class="container-fluid">
                    <div class="row mb-4">
                        <div class="col-md-7">
                            <img src="img/car.jpg" style="width: 800px;">
                        </div>
                        <div class="col-md-4">
                            <div class="container">
                                <form action="<?php echo e(url('/')); ?>/car-insurance-plan" method="post"  class="form" style="border: 1px solid lightgray; padding: 20px;">
                                <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label><b>Car Brand</b></label>
                                        <select type="select" name="brand" class="form-control mb-4" required>
                                            <option selected disabled value=""> Select Car Brand</option>
                                            <option value="Suzuki">Suzuki</option>
                                            <option value="Toyota">Toyota</option>
                                            <option value="Honda">Honda</option>
                                            <option value="Daihatsu">Daihatsu</option>
                                            <option value="Nissan">Nissan</option>
                                            <option value="Adam">Adam</option>
                                            <option value="Audi">Audi</option>
                                            <option value="Changan">Changan</option> 
                                            <option value="FAW">FAW</option>
                                            <option value="Hino">Hino</option>
                                            <option value="Hyundai">Hyundai</option>
                                            <option value="Jac">Jac</option>
                                            <option value="Jaguar">Jaguar</option>
                                            <option value="Jeep">Jeep</option>
                                            <option value="JMC">JMC</option>
                                            <option value="JW Forland">JW Forland</option>
                                            <option value="KIA">KIA</option>
                                            <option value="Land Rover">Land Rover</option>
                                            <option value="Mercedes">Mercedes</option>
                                            <option value="Lexus">Lexus</option>
                                            <option value="Mazda">Mazda</option>
                                            <option value="Mitsubishi">Mitsubishi</option>
                                            <option value="Porche">Porche</option>
                                            <option value="Range Rover">Range Rover</option>
                                            <option value="Tesla">Tesla</option> 
                                            <option value="United">United</option> 
                                            <option value="Prince">Prince</option>
                                            <option value="Isuzu">Isuzu</option>
                                            <option value="MG">MG</option>
                                            <option value="Proton">Proton</option>
                                            <option value="Haval">Haval</option> 
                                            <option value="Subaru">Subaru</option>
                                            <option value="Paugeot">Paugeot</option>
                                            <option value="Cherry">Cherry</option>
                                            <option value="Cadilac">Cadilac</option>
                                            <option value="BYD">BYD</option>
                                        </select>
                                        <label><b>Car Model</b></label>
                                        <input type="text" name="model" class="form-control mb-4" required>
                                        <select type="select" class="form-control mb-4" style="display: none;">
                                            <option selected> Select Car Model</option>

                                            <!-- Suzuki -->
                                            <!-- Alto ECO-S
                                            Alto X                        
                                            Alto E                        
                                            Alto Manual                        
                                            Alto ECO-L                        
                                            Alto F
                                            Alto G
                                            Alto G4
                                            Alto GII                      
                                            Alto L                      
                                            Alto Lapin                       
                                            Alto S Package
                                            Alto VP
                                            Alto VS
                                            Alto VX
                                            Alto VXR
                                            Alto X
                                            APV
                                            Baleno
                                            Bolan
                                            Carry
                                            Celerio
                                            Cervo
                                            Ciaz
                                            Cultus VX                    
                                            Cultus VX(CNG)                    
                                            Cultus VXL(CNG)                       
                                            Cultus VXR(CNG)   
                                            Cultus Auto Gear Shift
                                            Cultus Euro 11 -->



                                            <!-- Toyota -->
                                            <!-- Honda -->
                                            <!-- Daihatsu -->
                                            <!-- Nissan -->
                                            <!-- Adam -->
                                            <!-- Audi -->
                                            <!-- Changan --> 
                                            <!-- FAW -->
                                            <!-- Hino -->
                                            <!-- Hyundai -->
                                            <!-- Jac -->
                                            <!-- Jaguar -->
                                            <!-- Jeep -->
                                            <!-- JMC -->
                                            <!-- JW Forland -->
                                            <!-- KIA -->
                                            <!-- Land Rover -->
                                            <!-- Mercedes -->
                                            <!-- Lexus -->
                                            <!-- Mazda -->
                                            <!-- Mitsubishi -->
                                            <!-- Porche -->
                                            <!-- Range Rover -->
                                            <!-- Tesla --> 
                                            <!-- United --> 
                                            <!-- Prince -->
                                            <!-- Isuzu -->
                                            <!-- MG -->
                                            <!-- Proton -->
                                            <!-- Haval --> 
                                            <!-- Subaru -->
                                            <!-- Paugeot -->
                                            <!-- Cherry -->
                                            <!-- Cadilac -->
                                            <!-- BYD -->                                           

                                        </select>
                                        <label><b>Car Manufacturing Year</b></label>
                                        <select type="select" name="year" class="form-control mb-4" required>
                                            <option selected value=""> Select Manufacturing Year</option>
                                            <option value="2015">2015</option>
                                            <option value="2016">2016</option>
                                            <option value="2017">2017</option>
                                            <option value="2018">2018</option>
                                            <option value="2019">2019</option>
                                            <option value="2020">2020</option>
                                            <option value="2021">2021</option>
                                            <option value="2022">2022</option>
                                            <option value="2023">2023</option>
                                            <option value="2024">2024</option>
                                            <option value="2025">2025</option>
                                        </select>
                                        <label><b>Current Value</b></label>
                                        <input type="number" name="value" class="form-control mb-4" required>
                                        <label><b>Your Name</b></label>
                                        <input type="text" name="name" class="form-control mb-4" required>
                                        <label><b>Phone Number</b></label>
                                        <input type="text" name="phone" class="form-control mb-4" required>
                                        <input type="submit" class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-1">
                        <div>
                    </div>    
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../include/layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insurance-aggregator\resources\views/include/views/insurance/car.blade.php ENDPATH**/ ?>